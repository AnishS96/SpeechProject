package com.pojo;

public class CartItems {
	private int id;
	Products product;
	private int quantity;
	CustomerCart cart;

	private int getId() {
		return id;
	}

	private void setId(int id) {
		this.id = id;
	}

	private Products getProducts() {
		return product;
	}

	private void setProducts(Products products) {
		this.product = products;
	}

	private int getQuantity() {
		return quantity;
	}

	private void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
