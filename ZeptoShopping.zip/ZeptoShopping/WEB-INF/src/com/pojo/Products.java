package com.pojo;

public class Products {
	private int id;
	private int quantity;	
	private String products;
	private double price;
	private int getId() {
		return id;
	}
	private void setId(int id) {
		this.id = id;
	}
	private String getProducts() {
		return products;
	}
	private void setProducts(String products) {
		this.products = products;
	}
	private int getQuantity() {
		return quantity;
	}
	private void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
