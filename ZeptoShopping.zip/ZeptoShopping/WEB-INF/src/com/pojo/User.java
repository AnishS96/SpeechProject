package com.pojo;

public class User {
	private int id;
	private int pin;
	CustomerCart cart;

	private int getId() {
		return id;
	}
	private void setId(int id) {
		this.id = id;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}

}
