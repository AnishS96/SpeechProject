package com.pojo;

import java.util.List;

public class Category {
	private int id;
	private String category;
	List<Products> product;

	private int getId() {
		return id;
	}

	private void setId(int id) {
		this.id = id;
	}

	private String getCategory() {
		return category;
	}

	private void setCategory(String category) {
		this.category = category;
	}

}
