package com.pojo;

public class BillItem {
	private int id;
	Products product;
	private int quantity;
	private double price;

	private double getPrice() {
		return price;
	}

	private void setPrice(double price) {
		this.price = price;
	}

	private Products getProduct() {
		return product;
	}

	private void setProduct(Products product) {
		this.product = product;
	}

	private int getQuantity() {
		return quantity;
	}

	private void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	private int getId() {
		return id;
	}

	private void setId(int id) {
		this.id = id;
	}
}
