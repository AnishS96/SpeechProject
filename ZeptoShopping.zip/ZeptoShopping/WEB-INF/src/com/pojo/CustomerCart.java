package com.pojo;

import java.util.List;

public class CustomerCart {
	private int cartid;
	private User user;
	private List<CartItems>CartItems;
	
	private User getId() {
		return user;
	}
	private void setId(User id) {
		this.user = id;
	}
	private int getCartid() {
		return cartid;
	}
	private void setCartid(int cartid) {
		this.cartid = cartid;
	}
	private List<CartItems> getCartItems() {
		return CartItems;
	}
	private void setCartItems(List<CartItems> cartItems) {
		CartItems = cartItems;
	}
	
	
}
