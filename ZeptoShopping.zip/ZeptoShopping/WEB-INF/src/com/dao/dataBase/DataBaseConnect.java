package com.dao.dataBase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.commons.dbcp2.BasicDataSource;

public class DataBaseConnect {
	private static BasicDataSource connect = null;

	public BasicDataSource dataSource() {
		connect = new BasicDataSource();
		connect.setUrl("jdbc:sqlserver://192.168.168.12;databaseName=New_joinee_2022");
		connect.setUsername("NewJoinee2022");
		connect.setPassword("P@ssw0rd");
		connect.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

		connect.setMinIdle(5);
		connect.setMaxIdle(10);
		connect.setMaxTotal(25);
		return connect;
	}

	public void Connector(String query) throws Exception {

		Connection connection = null;
		Statement statement = null;
		try {
			connect = new DataBaseConnect().dataSource();
			connection = connect.getConnection();
			statement = connection.createStatement();
			statement.execute(query);

			System.out.println("Statement is executed");

		} catch (Exception e) {
			System.out.println(e);
		}

	}
	
	 public ResultSet SelectConnect(String query ) throws Exception {
			Connection connection = null;
			Statement statement = null;
			try {
				connect = new DataBaseConnect().dataSource();
				connection = connect.getConnection();
				statement = connection.createStatement();

				System.out.println("Statement is executed");

			} catch (Exception e) {
				System.out.println(e);
			}
			return null ;
	 	 
}
}