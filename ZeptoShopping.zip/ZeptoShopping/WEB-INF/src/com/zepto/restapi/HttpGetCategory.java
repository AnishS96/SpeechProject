package com.zepto.restapi;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

public class HttpGetCategory {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		try {
			DefaultHttpClient  client=new DefaultHttpClient();
			HttpGet get=new HttpGet("http://localhost:8011/ZeptoShopping/categoryTypes/listOfCategory");
			System.out.println("HttpMethod: "+get.getMethod());
			get.addHeader("Accept", "application/json");
			HttpResponse response=client.execute(get);
			
			if(response.getStatusLine().getStatusCode()==200) {
			BufferedReader br=new BufferedReader(new InputStreamReader(response.getEntity().getContent())); 
			String output;
			output=br.readLine();
			
			JSONObject json=new JSONObject(output);
			String string=json.getString("response");
			System.out.println("\nJsonObjectResponse: "+json.getString("response"));

			JSONArray array=(JSONArray)json.get("response");
			//System.out.println("\nArray: "+array.toString());
			for (int i = 0; i < array.length(); i++) {
				//System.out.println(array.get(i));
				JSONObject object=array.getJSONObject(i);
				System.out.println(object.getString("category"));	
			}
			br.close();
			}
			else {
				throw new RuntimeException("Failed :Http Error Code :"+response.getStatusLine().getStatusCode());
			}
			client.getConnectionManager().shutdown();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
