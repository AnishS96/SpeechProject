package com.zepto.restapi;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

public class HttpGetProducts {

	public static void main(String[] args) throws Exception{
		 getHttpRequest();
	}
	 @SuppressWarnings("resource")
	public static void getHttpRequest()throws Exception{
		try {
			//URL url=new URL("http://localhost:8011/ZeptoShopping/productTypes/listOfProducts/102");
			DefaultHttpClient  client=new DefaultHttpClient();
			HttpGet get=new HttpGet("http://localhost:8011/ZeptoShopping/productTypes/listOfProducts/101");
			System.out.println("HttpMethod: "+get.getMethod());
			get.addHeader("Accept", "application/json");
			HttpResponse response=client.execute(get);
			
			if(response.getStatusLine().getStatusCode()==200) {
			BufferedReader br=new BufferedReader(new InputStreamReader(response.getEntity().getContent())); 
			String output;
			output=br.readLine();
			
			JSONObject json=new JSONObject(output);
			String string=json.getString("response");
			System.out.println("\nJsonObjectResponse: "+json.getString("response"));

			JSONArray array=(JSONArray)json.get("response");
			//System.out.println("\nArray: "+array.toString());
			for (int i = 0; i < array.length(); i++) {
				//System.out.println(array.get(i));
				JSONObject object=array.getJSONObject(i);
				System.out.println(object.getString("productName"));	
			}
			br.close();
			}
			else {
				throw new RuntimeException("Failed :Http Error Code :"+response.getStatusLine().getStatusCode());
			}
			client.getConnectionManager().shutdown();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
