package com.zepto.restapi;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpGetCustomerValidation {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		try {
			URL url=new URL("http://localhost:8011/ZeptoShopping/zepto/oldUser");
			HttpURLConnection con=(HttpURLConnection) url.openConnection();
			con.setDoOutput(true);
			con.setRequestMethod("GET");
			con.setRequestProperty("accept", "application/json");
			String input="{\"id\":\"52\",\"pin\":\"8055\"}";
			OutputStream os=con.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			if(con.getResponseCode()==HttpURLConnection.HTTP_OK) {
			BufferedReader br=new BufferedReader(new InputStreamReader(con.getInputStream())); 
			String output;
			StringBuffer buffer=new StringBuffer();
			while((output=br.readLine())!=null) {
				buffer.append(output);
			}
			br.close();
			System.out.println("CustomerLogin: "+buffer.toString());
			}
			
			else {
				throw new RuntimeException("Failed :Http Error Code :"+con.getResponseCode());
			}
			con.disconnect();
			os.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
