package com.zepto.restapi;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

public class HttpCustomerLogin {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		try {
		
			URL url=new URL("http://localhost:8011/ZeptoShopping/zepto/addUser");
			HttpURLConnection con=(HttpURLConnection) url.openConnection();
			con.setDoOutput(true);
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json");
			String input="{\"pin\":\"3691\",\"phoneNumber\":\"563691\" }";
			OutputStream os=con.getOutputStream();
			os.write(input.getBytes());
			os.flush();
			if(con.getResponseCode()==HttpURLConnection.HTTP_OK) {
			BufferedReader br=new BufferedReader(new InputStreamReader(con.getInputStream())); 
			String output;
			output=br.readLine();
			
			JSONObject json=new JSONObject(output);
			String string=json.getString("response");
			System.out.println("\nJsonObjectResponse: "+json.getString("response"));
			System.out.println(string);
			br.close();
		
			}
			
			else {
				throw new RuntimeException("Failed :Http Error Code :"+con.getResponseCode());
			}
			con.disconnect();
			os.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
